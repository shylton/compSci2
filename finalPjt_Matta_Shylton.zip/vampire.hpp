/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  SPECIFICATION for the Vampire class. Member variables:
      - a vector to hold attack dice and one to hold defense dice
      - int for the character attributes of armor, strength and number of lives
    detailed function Descriptions in the implementation file.
*******************************************************************************/
#ifndef VAMPIRE_HPP
#define VAMPIRE_HPP

#include "character.hpp"

class Vampire : public Character {
public:
  Vampire(std::string userName = "Lestat");
  ~Vampire();
  int attack();
  int defend(int damagePts);
  void postFightReset();
  //void preFightSetup() {};
};

#endif /* end of include guard: VAMPIRE_HPP */

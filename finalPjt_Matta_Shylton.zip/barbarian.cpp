/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  IMPLEMENTATION for the Barbarian class.
*******************************************************************************/
#include "barbarian.hpp"

/*******************************************************************************
Constructor for the Barbarian class. Lets user choose the name.
inputs: nothing
return: nothing
*******************************************************************************/
Barbarian::Barbarian(std::string userName) {
  //2d6 Attack
  attackDie.push_back(Dice(6));
  attackDie.push_back(Dice(6));
  //1d6 Defense
  defenseDie.push_back(Dice(6));
  armor = 0;
  strength = 20;
  lives = 1;
  name = "Conan";
  characterClass = "Barbarian";
}

/*******************************************************************************
Destructor for the Barbarian class
inputs: nothing
return: nothing
*******************************************************************************/
Barbarian::~Barbarian() {

}

/*******************************************************************************
Barbarian attack function. Performs a dice roll for each defense die in the mem-
    ber vector.
inputs: calculated damage from the attack
return: int: the total damage taken
*******************************************************************************/
int Barbarian::attack() {
  int diceRoll;
  diceRoll = Character::attack();

  if (diceRoll > 9) {
    /* Strong Attack Message */
    std::cout << name << " the Barbarian executed a crushing blow!\n"
              << "ATTACK points: " << diceRoll << '\n';
  } else {
    std::cout << "ATTACK points: " << diceRoll << '\n';
  }

  return diceRoll;
}

/*******************************************************************************
Barbarian defend function. Performs a dice roll for each defense die in the
  member vector. prints a message to the screen, calculates the damage taken,
  update the strength attribute.
inputs: caclulated damage from the attack
return: int: the total damage taken
*******************************************************************************/
int Barbarian::defend(int damagePts) {
  int damageTaken, diceRoll;
  diceRoll = Character::defend(damagePts);
  damageTaken = std::max( 0, (damagePts - diceRoll - armor) );//cant be negative


  if (0 == damageTaken) {
    /* Parry defense message */
    std::cout << "DEFENSE points: " << diceRoll << '\n'
              << " ### Attack Parried! ###" << '\n'
              << "Inflicted damage: " << damageTaken << std::endl;
  } else {
    std::cout << "DEFENSE points: " << diceRoll << '\n'
              << "Inflicted damage: " << damageTaken << std::endl;
  }

  strength -= damageTaken; //update strength attribute

  //decrements the number of lives if strength reaches zero
  if (strength < 1) {
    std::cout << name << " updated strength: " << strength << '\n';
    std::cout << name << " is dead..." << '\n';
    --lives;
  } else {
    std::cout << name << " updated strength: " << strength << '\n';
  }

  return damageTaken;
}

/*******************************************************************************
Resets attributes post fight, to get ready for next one.
inputs: nothing
return: void
*******************************************************************************/
void Barbarian::postFightReset() {
  armor = 0;
  strength = 12;
  lives = 1;
}

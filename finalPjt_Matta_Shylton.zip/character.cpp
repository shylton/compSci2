/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  IMPLEMENTATION for the Character base class.
*******************************************************************************/

#include "character.hpp"

/*******************************************************************************
Default constructor for the base class
inputs: nothing
return: nothing
*******************************************************************************/
Character::Character() {

}

/*******************************************************************************
Destructor for the base class
inputs: nothing
return: nothing
*******************************************************************************/
Character::~Character() {

}

/*******************************************************************************
Returns the class name. To be used in screen prompts
inputs: nothing
return: string: class name, ex Barbarian
*******************************************************************************/
std::string Character::getClass() {
  return characterClass;
}


/*******************************************************************************
Returns the current strength. To be used in screen prompts and calculations
inputs: nothing
return: int: current strength points
*******************************************************************************/
int Character::getStrength() {
  return strength;
}


/*******************************************************************************
Returns the armor attribute. To be used in screen prompts and calculations
inputs: nothing
return: int: the armor attribute
*******************************************************************************/
int Character::getArmor() {
  return armor;
}

/*******************************************************************************
Returns the name attribute. To be used in screen prompts
inputs: nothing
return: string: character's name
*******************************************************************************/
std::string Character::getName() {
  return name;
}

/*******************************************************************************
Returns true if the character has 0 or less lives
inputs: nothing
return: bool
*******************************************************************************/
bool Character::isDead() {
  bool rtn = false;
  if (lives < 1) {
    rtn =  true;
  }
  return rtn;
}

/*******************************************************************************
increases level
inputs: nothing
return: void
*******************************************************************************/
void Character::levelUp() {
  level++;
  std::cout << "You leveled up. Congratulations!" << '\n';
}

/*******************************************************************************
inputs: nothing
return: int: level
*******************************************************************************/
int Character::getLevel() {
  return level;
}

/*******************************************************************************
decrements step counter
inputs: nothing
return: void
*******************************************************************************/
void Character::setMoves(int input) {
  moves += input;

  if (1 == moves) {
    std::cout << " ## THIS IS YOUR LAST DAY ##" << '\n';
    std::cout << "Press [Enter] to continue ";
    std::cin.get();
  }
  if (moves < 1) {
    std::cout << "You have no days left. Game Over..." << '\n';
    theEnd = true;
  }
}

/*******************************************************************************
inputs: nothing
return: bool: true if step counter reaches zero, ie end game
*******************************************************************************/
bool Character::endGame() {
  return theEnd;
}

/*******************************************************************************
inputs: nothing
return: int: stepCounter
*******************************************************************************/
int Character::getMoves() {
  return moves;
}

/*******************************************************************************
inputs: nothing
return: int: stepCounter
*******************************************************************************/
void Character::showStats() {
  std::cout << "Remaining days: " << moves << "\n\n";
  std::cout << "Level | armor | strength points\n";
  std::cout.width(6); std::cout << std::left << getLevel() << "|   ";
  std::cout.width(4); std::cout << getArmor() << '|';
  std::cout << "   " << getStrength() << std::endl;

  std::cout << "Attack dice count:  " << attackDie.size() << '\n'
            << "Defense dice count: " << defenseDie.size() << std::endl;
}


/*******************************************************************************
Default attack function. Abstract function that MUST be overriden in the child
  classes. Performs a dice roll for each attack die in the member vector
inputs: nothing
return: the sum of the attack dice rolls
*******************************************************************************/
int Character::attack() {
  int diceRoll, total = 0;

  std::cout << "\nAttacker dice roll(s):";
  for (int i = 0; i < attackDie.size(); i++) {
    diceRoll = attackDie[i].roll();
    std::cout << ' ' << diceRoll;
    total += diceRoll;
  }
  std::cout << std::endl;
  return total;
}

/*******************************************************************************
Default defend function. Abstract function that MUST be overriden in the child
  classes. Performs a dice roll for each defense die in the member vector.
inputs: nothing
return: the sum of the defense dice rolls
*******************************************************************************/
int Character::defend(int damagePts) {
  int diceRoll, total = 0;

  std::cout << "\nDefender dice roll(s):";
  for (int i = 0; i < defenseDie.size(); i++) {
    diceRoll = defenseDie[i].roll();
    std::cout << ' ' << diceRoll;
    total += diceRoll;
  }
  std::cout << std::endl;
  return total;
}

/*******************************************************************************
Sets up armor, dice count etc pre fight. CAN ONLY BE CALLED FOR HERO (HARRY P)!
inputs: nothing
return: void
*******************************************************************************/
void Character::preFightSetup() {
  attackDie.clear();

  int shieldsHeld = backpack->itemCount(shield);
  armor += shieldsHeld;
  backpack->removeItem(shieldsHeld, shield);

  if (level >= 8) {
    //4d6 Attack
    attackDie.push_back(Dice(6));
    attackDie.push_back(Dice(6));
    attackDie.push_back(Dice(6));
    attackDie.push_back(Dice(6));
  } else if (level >= 4) {
    //3d6 Attack
    attackDie.push_back(Dice(6));
    attackDie.push_back(Dice(6));
    attackDie.push_back(Dice(6));
  } else {
    //2d6 Attack
    attackDie.push_back(Dice(6));
    attackDie.push_back(Dice(6));
  }
}

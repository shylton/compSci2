/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  Header file for the inventory Space class, this the left space
    where you can deal with inventory.
    - to the right there is a base space
    - all other directions are null
*******************************************************************************/
#include "inventorySpace.hpp"

/*******************************************************************************
constructor
inputs: string: name, int boss to setup opponent
return: void
*******************************************************************************/
InventorySpace::InventorySpace(std::string nm, int boss) : Space () {
  name = nm;
  unlockLvl = boss;
  chest = new Storage(9);
}

/*******************************************************************************
Destructor
inputs: string: name, int boss to setup opponent
return: void
*******************************************************************************/
InventorySpace::~InventorySpace() {
  delete chest;
}

/*******************************************************************************
performs inventory management
inputs: pointer to character
return: pointer to next space
*******************************************************************************/
Space* InventorySpace::action(Space *currSpace) {
  int usrChoice, itemQty, itemType;
  items itm;

  clearScrn();
  inventoryGreeting();
  std::cout << "\nBackpack:\n";
  hero->backpack->showItems();
  std::cout << "\nChest:" << '\n';
  chest->showItems();

  do {
    usrChoice = inventorySelectMenu();

    switch (usrChoice) {
      case 1: {
        std::cout << "\nBackpack:\n";
        hero->backpack->showItems();
        std::cout << "\nChest:" << '\n';
        chest->showItems();
        break;
      }
      case 2: {
        moveItemsMenu(itemType, itemQty, "moved TO chest");
        if (4 == itemType) {
          /* user chose to cancel the operation, do nothing */
        } else {
          itm = items(itemType);//type conversion
          itemQty = std::min( itemQty, hero->backpack->itemCount(itm) );
          hero->backpack->removeItem(itemQty, itm);
          chest->addItem(itemQty, itm);
        }
        break;
      }
      case 3: {
        moveItemsMenu(itemType, itemQty, "moved FROM chest");
        if (4 == itemType) {
          /* user chose to cancel the operation, do nothing */
        } else {
          itm = items(itemType);//type conversion
          itemQty = std::min( itemQty, chest->itemCount(itm) );
          chest->removeItem(itemQty, itm);
          hero->backpack->addItem(itemQty, itm);
        }
        break;
      }
      case 4: {
        moveItemsMenu(itemType, itemQty, "moved FROM chest");
        if (4 == itemType) {
          /* user chose to cancel the operation, do nothing */
        } else {
          itm = items(itemType);//type conversion
          itemQty = std::min( itemQty, chest->itemCount(itm) );
          chest->removeItem(itemQty, itm);
        }
        break;
      }
    } //end of switch

  } while(usrChoice != 5);

  return toRight;
}

/*******************************************************************************
get inputs to move items to/from backpack and chest
inputs: nothing
return: int by ref: the user selections
*******************************************************************************/
void InventorySpace::moveItemsMenu(int &iType, int &iQty, std::string s) {
  int usrChoice;

  std::cout << "\nItem(s) to be " << s << " if possible:\n"
            << "   1. Life-Gem\n"
            << "   2. Holy-Garlic\n"
            << "   3. Plank-Shield\n"
            << "   4. Cancel ";
  usrChoice = getInt (1,4);
  iType = usrChoice;
  std::cout << "How many? ";
  iQty = getInt();
}

/*******************************************************************************
* Author:       Shylton Matta
* Date:         27 Jul 2019
* Description:  SPECIFICATION for some useful helper functions. Mainly used to
        display menus and get and validate user inputs. Specific function desc-
        riptions can be found in the IMPLEMENTATION file.
*******************************************************************************/

#ifndef HELPERS_HPP
#define HELPERS_HPP

#include <iostream>
#include <string>
#include <iomanip>

/*******************************************************************************
* Main Helpers class. This is where menu functions will be implemented
*******************************************************************************/

//functions used in main
  int mainMenu();
  int getInt();
  int getInt(int low, int high);
  char getYN();//returns capital 'Y' or 'N'
  void pressKey();
  void showHistory();
  void clearScrn();
  void showMap();

//functions used in Game
  int selectPlayer(char p);
  bool playAgain();
  void intro();

//InventorySpace menus
  void inventoryGreeting();
  int inventorySelectMenu();





#endif

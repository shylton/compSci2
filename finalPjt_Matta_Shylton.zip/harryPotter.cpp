/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  IMPLEMENTATION for the HarryPotter class. Our hero is based on
    the previous harry potter class.
*******************************************************************************/
#include "harryPotter.hpp"

/*******************************************************************************
Constructor for the HarryPotter class. Lets user choose the name.
inputs: nothing
return: nothing
*******************************************************************************/
HarryPotter::HarryPotter(std::string userName) : Character() {
  //2d6 Attack
  attackDie.push_back(Dice(6));
  attackDie.push_back(Dice(6));
  //1d6 Defense
  defenseDie.push_back(Dice(6));
  armor = 0;
  strength = 20;
  lives = 1;
  level = 1;
  moves = 15;
  name = userName;
  characterClass = "Hero";
  theEnd = false;
  backpack = new Storage(6);
}

/*******************************************************************************
Destructor for the HarryPotter class
inputs: nothing
return: nothing
*******************************************************************************/
HarryPotter::~HarryPotter() {
  delete backpack;
}

/*******************************************************************************
HarryPotter attack function. Performs a dice roll for each defense die in the mem-
    ber vector.
inputs: calculated damage from the attack
return: int: the total damage taken
*******************************************************************************/
int HarryPotter::attack() {
  int diceRoll;
  diceRoll = Character::attack();

  if (diceRoll > 9) {
    /* Strong Attack Message */
    std::cout << Character::getName() << " executed a Crushing Blow!\n"
              << "ATTACK points: " << diceRoll << '\n';
  } else {
    std::cout << "ATTACK points: " << diceRoll << '\n';
  }

  return diceRoll;
}

/*******************************************************************************
HarryPotter defend function. Performs a dice roll for each defense die in the
  member vector. prints a message to the screen, calculates the damage taken,
  update the strength attribute.
inputs: caclulated damage from the attack
return: int: the total damage taken
*******************************************************************************/
int HarryPotter::defend(int damagePts) {
  int damageTaken, diceRoll;
  diceRoll = Character::defend(damagePts);
  damageTaken = std::max( 0, (damagePts - diceRoll - armor) );//cant be negative


  if (0 == damageTaken) {
    /* Parry defense message */
    std::cout << "DEFENSE points: " << diceRoll << '\n'
              << " ### Attack Parried! ###" << '\n'
              << "Inflicted damage: " << damageTaken << std::endl;
  } else {
    std::cout << "DEFENSE points: " << diceRoll << '\n'
              << "Inflicted damage: " << damageTaken << std::endl;
  }

  strength -= damageTaken; //update strength attribute

  //call hogwarts if there is more than one life
  if (strength < 1 && backpack->itemCount(lifeGem) > 0) {
    std::cout << Character::getName() << " updated strength: " << strength << '\n';
    std::cout << " ### Using Life-Gem to revive ###\n";
    backpack->removeItem(1,lifeGem);
    strength = 20;
  } else if (strength < 1) {
    /* code */
    std::cout << Character::getName() << " is dead..." << '\n';
    --lives;
  } else {
    std::cout << name << " updated strength: " << strength << '\n';
  }

  return damageTaken;
}

/*******************************************************************************
Resets attributes post fight, to get ready for next one.
inputs: nothing
return: void
*******************************************************************************/
void HarryPotter::postFightReset() {
  armor = 0;
  strength = 20;
  lives = 1;
}

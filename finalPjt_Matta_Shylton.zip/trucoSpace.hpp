/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  Header file for the card game space class. here the player has
    the option of playing a card game to win quest items.
*******************************************************************************/

#ifndef TRUCOSPACE_HPP
#define TRUCOSPACE_HPP

#include "helpers.hpp"
#include "space.hpp"
#include "truco.hpp"

class TrucoSpace : public Space {
private:
  Truco *newGame;
  int score;

public:
  TrucoSpace (std::string nm, int boss);
  ~TrucoSpace ();
  Space* action(Space *currSpace);
  void greeting();
  int selectMenu();
  void trucoRules();
  void kronosMsg();
  void gamble();
  int gambleMenu();
  void playTruco();
};


#endif /* end of include guard: TRUCOSPACE_HPP */

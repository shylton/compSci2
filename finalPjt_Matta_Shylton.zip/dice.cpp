/*******************************************************************************
* Author:       Shylton Matta
* Date:         27 Jul 2019
* Description:  IMPLEMENTATION for three recursive functions.
    1. reverseString Reverses the string passed to it.
    2. sumArray sums an array of ints passed to it.
    3. triangularNumber receives N and returns the Nth triangular number.
*******************************************************************************/

#include "dice.hpp"

/*******************************************************************************
Constructor for the class
inputs: int with the number of sides
return: nothing
*******************************************************************************/
Dice::Dice(int s) {
  sides = s;
}

/*******************************************************************************
Returns a random number between 1 and the number of sides
inputs: nothing
return: int: random number
*******************************************************************************/
int Dice::roll() {
  return ((rand() % sides) + 1);
}

/*******************************************************************************
Resets the number of sides. Used in the blue men class, gets set to zero in order
  to remove a dice
inputs: nothing
return: int: random number
*******************************************************************************/
void Dice::setSides(int s) {
  sides = s;
}

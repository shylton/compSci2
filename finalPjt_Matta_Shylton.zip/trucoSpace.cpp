/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  Header file for the card game space class. here the player has
    the option of playing a card game to win quest items.
*******************************************************************************/
#include "trucoSpace.hpp"

/*******************************************************************************
constructor
inputs: string: name, int boss to setup opponent
return: nothing
*******************************************************************************/
TrucoSpace::TrucoSpace(std::string nm, int boss) : Space () {
  name = nm;
  unlockLvl = boss;
  newGame = new Truco;
}

/*******************************************************************************
Destructor
inputs: string: name, int boss to setup opponent
return: nothing
*******************************************************************************/
TrucoSpace::~TrucoSpace() {
  delete newGame;
}

/*******************************************************************************
Menu options to play or move
inputs: pointer to character
return: pointer to next space
*******************************************************************************/
Space* TrucoSpace::action(Space *currSpace) {
  int usrChoice;

  do {
    clearScrn();
    greeting();
    usrChoice = selectMenu();

    switch (usrChoice) {
      case 1: {
        gamble();
        break;
      }
      case 2: {
        trucoRules();
        break;
      }
      case 3: {
        kronosMsg();
        break;
      }
    } //end of switch

  } while(usrChoice != 4);

  return toLeft;
}

/*******************************************************************************
Menu options
inputs: none
return: int: user selection
*******************************************************************************/
void TrucoSpace::gamble() {
  int usrChoice;

  do {
    clearScrn();
    //greeting();
    usrChoice = gambleMenu();

    switch (usrChoice) {
      case 1: {
        playTruco();

        break;
      }
      case 2: {
        playTruco();

        if (score >= 0 ) {
          hero->backpack->addItem(score, lifeGem);
        } else {
          hero->setMoves(score);
        }
        score = 0;//reset score
        break;
      }
      case 3: {
        playTruco();

        if (score >= 0 ) {
          hero->backpack->addItem(score, shield);
        } else {
          hero->setMoves(score);
        }
        score = 0;//reset score
        break;
      }
      case 4: {
        playTruco();

        hero->setMoves(score);
        score = 0;//reset score
        break;
      }
      case 5: {
        std::cout << "Backpack:" << '\n';
        hero->backpack->showItems();
        std::cout << std::endl;
        hero->showStats();
        pressKey();
        break;
      }
    } //end of switch

  } while(usrChoice != 6);
}

/*******************************************************************************
display a greeting
inputs: none
return: void
*******************************************************************************/
void TrucoSpace::greeting() {
  std::cout << std::string(64,'=') << std::endl
            << '|' << std::string(19, ' ')
            << "Welcome to " << Space::getName()
            << std::string(19, ' ') << "|\n"
            << '|' << std::string(2, ' ')
            << "Grab a biscuit at the door and come in. Or get outta here."
            << std::string(2, ' ') << "|\n"
            << std::string(64,'=') << std::endl;
}

/*******************************************************************************
Menu options to play or move
inputs: none
return: int: user selection
*******************************************************************************/
int TrucoSpace::selectMenu() {
  int usrChoice;

  std::cout << "\nPlease select from the following options:\n"
            << "   1. Gamble\n"
            << "   2. Card Game (truco) rules\n"
            << "   3. What's krono's deal anyways?\n"
            << "   4. Exit [go back Home] ";
  usrChoice = getInt (1,4);
  return usrChoice;

  return 4;
}

/*******************************************************************************
displays guide to game
inputs: none
return: void
*******************************************************************************/
void TrucoSpace::trucoRules() {
  clearScrn();
  std::cout << std::string(64,'*') << '\n'
            << "   Truco is very popular card game in Brazil. Krono's likes to\n"
            << " play a simplified version of that game. For more information\n"
            << " on the full game, this is a good resource:\n"
            << "      https://www.pagat.com/put/truco_br.html\n" << std::endl;

  std::cout << "   A. THE DECK" << '\n'
            << " Consisted of 20 cards per below:\n"
            << "[qty][card]:[value]\n   1x A:8\n   1x K:7\n   1x Q:6\n"
            << "   1x J:5\n   4x 5:4\n   4x 4:3\n   4x 3:2\n   4x 2:1\n" << std::endl;

  std::cout << "   B. GAMEPLAY" << '\n'
            << "   Two players get 3 cards from the shuffled deck each.\n"
            << "   First to act will be randomly choosen.\n"
            << "   The winner of the previous round acts first in the next.\n"
            << "   The winner of the game will be determined in three rounds of\n"
            << " play. The winner of each round is determined by the value of\n"
            << " the cards played per table above.\n\n"
            << " TieBreaking:\n"
            << " - FIRST ROUND TIE: \n"
            << "   Players MUST play their highest card in the second round, the\n"
            << "     winner takes the game.\n"
            << "   If there is another tie in the second round, then we move to\n"
            << "     a third round (in this rare case, there can't be a tie in\n"
            << "     3rd round since there's only 4 cards with the same value)\n\n";
  std::cout << " - SECOND and THIRD ROUND TIE:" << '\n'
            << "   The winner of the FIRST round wins the game.\n\n";
  std::cout << "   C. TIPS" << '\n'
            << "   - the first round is important since its the tiebreaker\n"
            << "   - pay attention to the card played by your opponent, since it\n"
            << "      shows their hand strength (absent bluffing...)\n"
            << "   - a strong hand will have one of the top 4 cards\n"
            << "   - a weak hand will have nothing above 3's and 4's\n" << std::endl;
  std::cout << " That's pretty much the gist. The full game has a different\n"
            << " scoring system, bigger deck, different special cards, etc...\n"
            << std::string(64,'*') << '\n';

  pressKey();
}

/*******************************************************************************
displays a message from Kronos
inputs: none
return: void
*******************************************************************************/
void TrucoSpace::kronosMsg() {
  clearScrn();
  std::cout << std::string(64,'*') << '\n';
  std::cout << "   Hi, I'm Kronos, god of time and space. I'm glad you're here,\n"
            << " it's been lonely since I created the universe.\n"
            << "   My favorite thing to do with humans is to gamble and beat\n"
            << " them in my favorite card game. And what does the god of time\n"
            << " like to gamble with? YOUR time of course.\n"
            << "   If you beat me, I can give you precious items to aid in your\n"
            << " quest, including the most precious - time itself!\n"
            << "   But if you lose, I will fill my belly with your last days...\n\n";

  std::cout << "[you can play multiple games of truco, at the end, if your score\n"
            << "is negative you lose that many days, or win that same qty of an\n"
            << "item of your choice]\n"
            << "   Make sure you have empty slots in your backpack!\n";
  std::cout << std::string(64,'*') << std::endl;
  pressKey();
}

/*******************************************************************************
Menu options
inputs: none
return: int: user selection
*******************************************************************************/
int TrucoSpace::gambleMenu() {
  int usrChoice;

  std::cout << std::string(64,'*') << '\n';
  std::cout << "\nWhat would you like to win?\n"
            << "   1. Nothing - just practice\n"
            << "   2. Life Gems  [revive during combat then break]\n"
            << "   3. Shields    [low quality, +armor then break]\n"
            << "   4. Days       [Kronos can give you more days]\n"
            << "   5. Check your backpack and Stats\n"
            << "   6. Exit ";
  usrChoice = getInt (1,6);
  std::cout << std::string(64,'*') << std::endl;

  return usrChoice;
}

/*******************************************************************************
plays the game, updates the score variable
inputs: none
return: void
*******************************************************************************/
void TrucoSpace::playTruco() {
  int mais1 = 0;

  do {
    clearScrn();
    score = newGame->letsPlay();
    std::cout << "press 1 to play again, 0 to quit: ";
    mais1 = getInt(0,1);
  } while(1 == mais1);
}

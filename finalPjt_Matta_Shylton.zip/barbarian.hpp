/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  SPECIFICATION for the Barbarian class. Member variables:
      - a vector to hold attack dice and one to hold defense dice
      - int for the character attributes of armor, strength and number of lives
    detailed function Descriptions in the implementation file.
*******************************************************************************/
#ifndef BARBARIAN_HPP
#define BARBARIAN_HPP

#include "character.hpp"

class Barbarian : public Character {
public:
  Barbarian(std::string userName = "Conan");
  ~Barbarian();
  int attack();
  int defend(int damagePts);
  void postFightReset();
  //void preFightSetup();
};

#endif /* end of include guard: BARBARIAN_HPP */

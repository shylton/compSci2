/*******************************************************************************
* Author:       Shylton Matta
* Date:         27 Jul 2019
* Description:  SPECIFICATION for the dice class
*******************************************************************************/
#ifndef GAME_HPP
#define GAME_HPP

#include "helpers.hpp"
#include "character.hpp"
#include "barbarian.hpp"  //1
#include "vampire.hpp"    //4
#include "blueMen.hpp"    //2
#include "medusa.hpp"     //5
#include "harryPotter.hpp"//3

class Game {
private:
  Character *attacker,
            *defender;

  int currentRound;

public:
  Game();
  Game(Character *p1, Character *p2);
  ~Game();
  void swapAttacker();
  int start1();
  void endFight();
};


#endif /* end of include guard: GAME_HPP */

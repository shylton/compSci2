/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  IMPLEMENTATION for the BlueMen class.
*******************************************************************************/
#include "blueMen.hpp"

/*******************************************************************************
Constructor for the BlueMen class. Lets user choose the name.
inputs: nothing
return: nothing
*******************************************************************************/
BlueMen::BlueMen(std::string userName) {
  //2d10 Attack
  attackDie.push_back(Dice(10));
  attackDie.push_back(Dice(10));
  //3d6 Defense
  defenseDie.push_back(Dice(6));
  defenseDie.push_back(Dice(6));
  defenseDie.push_back(Dice(6));
  armor = 3;
  strength = 12;
  lives = 1;
  name = "Na'vi";
  characterClass = "Blue Men";
}

/*******************************************************************************
Destructor for the BlueMen class
inputs: nothing
return: nothing
*******************************************************************************/
BlueMen::~BlueMen() {

}

/*******************************************************************************
BlueMen attack function. Performs a dice roll for each defense die in the mem-
    ber vector.
inputs: calculated damage from the attack
return: int: the total damage taken
*******************************************************************************/
int BlueMen::attack() {
  int diceRoll;
  diceRoll = Character::attack();

  if (diceRoll > 9) {
    /* Strong Attack Message */
    std::cout << name << " the Blue Men executed a crushing blow!\n"
              << "ATTACK points: " << diceRoll << '\n';
  } else {
    std::cout << "ATTACK points: " << diceRoll << '\n';
  }

  return diceRoll;
}

/*******************************************************************************
BlueMen defend function. Performs a dice roll for each defense die in the
  member vector. prints a message to the screen, calculates the damage taken,
  update the strength attribute.
inputs: caclulated damage from the attack
return: int: the total damage taken
*******************************************************************************/
int BlueMen::defend(int damagePts) {
  int damageTaken, diceRoll;
  diceRoll = Character::defend(damagePts);
  damageTaken = std::max( 0, (damagePts - diceRoll - armor) );//cant be negative


  if (0 == damageTaken) {
    /* Parry defense message */
    std::cout << "DEFENSE points: " << diceRoll << '\n'
              << " ### Attack Parried! ###" << '\n'
              << "Inflicted damage: " << damageTaken << std::endl;
  } else {
    std::cout << "DEFENSE points: " << diceRoll << '\n'
              << "Inflicted damage: " << damageTaken << std::endl;
  }

  strength -= damageTaken; //update strength attribute
  resetDiceCount();//sets dice count based on level of strength

  //decrements the number of lives if strength reaches zero
  if (strength < 1) {
    std::cout << name << " updated strength: " << strength << '\n';
    std::cout << name << " is dead..." << '\n';
    --lives;
  } else {
    std::cout << name << " updated strength: " << strength << '\n';
  }

  return damageTaken;
}

/*******************************************************************************
BlueMen member function to remove defense dice.
inputs: nothing
return: nothing
*******************************************************************************/
void BlueMen::resetDiceCount() {
  defenseDie.clear();

  if (strength >= 9) {
    //3d6 Defense
    defenseDie.push_back(Dice(6));
    defenseDie.push_back(Dice(6));
    defenseDie.push_back(Dice(6));
  } else if (strength >= 5) {
    //2d6 Defense
    defenseDie.push_back(Dice(6));
    defenseDie.push_back(Dice(6));
  } else {
    //1d6 Defense
    defenseDie.push_back(Dice(6));
  }
}

/*******************************************************************************
Resets attributes post fight, to get ready for next one.
inputs: nothing
return: void
*******************************************************************************/
void BlueMen::postFightReset() {
  armor = 3;
  strength = 12;
  lives = 1;
}

/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  IMPLEMENTATION for some useful helper functions. Mainly used to
        display menus and get and validate user inputs.
*******************************************************************************/
#include "helpers.hpp"

/*******************************************************************************
* Function to validate whether the input is an integer.
  Source: https://www.youtube.com/watch?v=YIX7UhIKEIk&t=316s
*******************************************************************************/
int getInt() {
  int rtn;
  while (!(std::cin >> rtn)) {
    std::cout << "[WARNING] Must be an integer. Please try again. ";
    std::cin.clear();
    std::cin.ignore(256, '\n');
  }

  /*if user enters an integer followed by other characters, the procedure above
    extracts the integer but leaves the other chars in the input stream.
    below should skip any characters left in the input stream by mistake*/
  std::cin.clear();
  std::cin.ignore(256, '\n');

  return rtn;
}

/*******************************************************************************
* Function to validate whether the input is an integer. AND between low and high
  Source: https://www.youtube.com/watch?v=YIX7UhIKEIk&t=316s
*******************************************************************************/
int getInt(int low, int high) {
  int rtn;
  bool looper = true;

  do {
    //STEP 1. Is it int?
    while (!(std::cin >> rtn)) {
      std::cout << "[WARNING] Must be an integer. Please try again. ";
      std::cin.clear();
      std::cin.ignore(256, '\n');
    }
    /*if user enters an integer followed by other characters, the procedure above
      extracts the integer but leaves the other chars in the input stream.
      below should skip any characters left in the input stream by mistake*/
    std::cin.clear();
    std::cin.ignore(256, '\n');

    //STEP 2. is it valid int?
    if (rtn >= low && rtn <= high) {
      looper = false;
    } else {
      std::cout << "[WARNING] Input must be between " << low << " and "
                << high << ".\nPlease try again: ";
    }

  } while(looper);
  return rtn;
}

/*******************************************************************************
* Function to validate Yes or No input. Takes a string input and returns a
    capital 'Y' char for yes or a capital 'N' char for no.
*******************************************************************************/
char getYN() {
  char siOrNo;
  std::string userInput;
  bool error = true;

  do {
    std::getline(std::cin, userInput);
    siOrNo = userInput[0];

    if (("Y" == userInput) || ("y" == userInput) ||
        ("yes" == userInput) || ("Yes" == userInput)) {
      siOrNo = 'Y';
      error = false;
    }
    else if (("N" == userInput) || ("n" == userInput) ||
        ("no" == userInput) || ("No" == userInput)) {
      siOrNo = 'N';
      error = false;
    }

    if (error) {
      std::cout << "[WARNING] Bad input, should be either yes or no."
                << " Please try again. ";
    }
  } while(error) ;

  return siOrNo;
}

/*******************************************************************************
Press key to continue
inputs: nothing
return: void
*******************************************************************************/
void pressKey() {
  std::cout << "\nPress [Enter] to continue ";
  std::cin.get();
}

/*******************************************************************************
Source: http://www.cplusplus.com/articles/4z18T05o/
inputs: nothing
return: 100 new lines to clear up the screen
*******************************************************************************/
void clearScrn() {
  std::cout << std::string( 100, '\n' );
}

/*******************************************************************************
inputs: nothing
return: int: the user choice
*******************************************************************************/
int mainMenu() {
  int rtn; //return
  clearScrn();
  std::cout << std::string(64,'=') << std::endl
            << '|' << std::string(19, ' ')
            << "### A Hero's Journey ###"
            << std::string(19, ' ') << "|\n"
            << std::string(64,'=') << "\n\n";

  std::cout << "  ## Main Menu ## " << '\n'
            << "   1. Start New Game\n"
            << "   2. Show History\n"
            << "   3. Show Map\n"
            << "   4. Quit Game  ";
  rtn = getInt(1,4);
  return rtn;
}

/*******************************************************************************
inputs: nothing
return: void
*******************************************************************************/
void showHistory () {
  //clearScrn();
  std::cout << std::string(25,' ') << "/* HISTORY */\n\n"
            << "    When Medusa's sister Scylla told her she would trade the \n"
            << " recently acquired head of king Pelops for the last polar bear\n"
            << " still alive in men's land, Medusa jumped on the opportunity\n"
            << " and knew exaclty who to enlist to help her: Laufey the Just.\n\n"
            << "    Laufey (Faye for short) who is the wife of the hero Kratos,\n"
            << " was not pleased with the idea of giving the last polar bear to\n"
            << " the gods to play with. Faye (who is also know as Feisty-Faye)\n";

  std::cout << " let Medusa have it with ah hour long lecture on how the gods\n"
            << " were responsible for the global warming and the disappearance\n"
            << " of all but one of the polar bears; who was safely hidden.\n\n"
            << "    'So you know where it is...' said Medusa. Seeing that her\n"
            << " speech had fallen on deaf ears, Faye told Medusa to leave once\n"
            << " and for all. Medusa had other ideas. She grabbed Faye by the\n"
            << " hair and they both teleported to Medusa's Lair.\n\n";

  std::cout << "    Back in the Lair, Medusa is working with a magic spell that\n"
            << " makes any human tell the truth. But Faye has hero's blood.\n"
            << "    Unknown to Medusa, the spell not only does not work on Faye,\n"
            << " but it kills her after some time.\n\n"
            << "    This is where we pick up the story, our hero, Kratos must\n"
            << " rescue his beautiful wife before she runs out of time !\n\n";
  pressKey();
}

/*******************************************************************************
inputs: nothing
return: void
*******************************************************************************/
void showMap () {
  std::cout << std::string(64, '=') << '\n'
            << "                  ___________                               \n"
            << "           Lvl 4  |  Medusa |                               \n"
            << "                  -----------                               \n"
            << "                  ___________                               \n"
            << "           Lvl 3  |  Na'vi  |                               \n"
            << "                  -----------                               \n"
            << "                  ___________                               \n"
            << "           Lvl 2  |  Lestat |                               \n"
            << "                  -----------                               \n"
            << "                  ___________     [inventory and Krono's]       \n"
            << "           Lvl 1  |  Conan  |   [may be accessed from anywhere] \n"
            << "                  -----------                                   \n"
            << "                  ___________      ___________                  \n"
            << " [Inventory] <--- |  Home   | ---> | Krono's |                  \n"
            << "                  -----------      |  House  |                  \n"
            << "                                   -----------\n"
            << std::string(64, '=') << std::endl;
  pressKey();
}
/*******************************************************************************
Menu with validation for character selection.
inputs: char: A or B for playerA and playerB
return: int: the user choice from 1 to 5 per below
*******************************************************************************/
int selectPlayer(char p) {
  int userInput;
  bool looper;

  std::cout << "\nSelect Player ## " << p << " ## from the following options:\n"
            << "   1. Conan the Barbarian\n"
            << "   2. Blue Men Mob\n"
            << "   3. Harry Potter\n"
            << "   4. Lestat the Vampire\n"
            << "   5. Medusa\n"
            << "[type 1 - 5] -> ";

  do {
    looper = false;
    userInput = getInt();
    if (userInput < 1 || userInput > 5) {
      /* user did not choose between 1 and 5 */
      looper = true;
      std::cout << "Bad Input. Please type a number between 1 and 5 "
                << "followed by [ENTER]: ";
    }
  } while(looper);
  return userInput;
}

/*******************************************************************************
Menu with validation for character selection for the play again menu.
inputs: nothing
return: bool: the user choice, true to play again false otherwise
*******************************************************************************/
bool playAgain() {
  int userInput;
  bool looper, rtn;

  std::cout << "\nPlease select from the following options:\n"
            << "   1. Play again\n"
            << "   2. Exit the game\n"
            << "[type 1 - 2] -> ";

  do {
    looper = false;
    userInput = getInt();
    if (userInput < 1 || userInput > 2) {
      /* user did not choose between 1 and 5 */
      looper = true;
      std::cout << "Bad Input. Please type '1' or '2' followed by [ENTER]: ";
    }
  } while(looper);

  if (1 == userInput) {//play game again
    rtn = true;
  } else {
    rtn = false;
  }
  std::cout << std::string(64,'=') << std::endl;
  return rtn;
}

/*******************************************************************************
Shows intro message
inputs: nothing
return: void
*******************************************************************************/
void intro() {
  std::cout << std::string(64,'=') << '\n'
            << std::string(19,' ') << "### Fantasy Fight Game ###\n"
            << std::string(64,'=') << '\n'
            << "Welcome to Fantasy Fight, the game where you choose two players\n"
            << " to fight to the death. Rules:\n"
            << " - choose a class for playerA and then for playerB\n"
            << " - the first player to attack is randomly selected\n"
            << " - attacker and defender are swapped in subsequent rounds\n"
            << " - Game will run until one of the players is dead\n"
            << "      LET'S PLAY !\n"
            << std::string(64,'=') << std::endl;
}

/*******************************************************************************
Shows intro message for inventory space
inputs: nothing
return: void
*******************************************************************************/
void inventoryGreeting() {
  std::cout << std::string(64,'=') << std::endl
            << '|' << std::string(10, ' ')
            << "Welcome to your personal inventory space."
            << std::string(11, ' ') << "|\n"
            << '|' << std::string(13, ' ')
            << "You can manage your inventory here."
            << std::string(14, ' ') << "|\n"
            << std::string(64,'=') << std::endl;
}

/*******************************************************************************
Menu with inventory management options
inputs: nothing
return: int: the user selection
*******************************************************************************/
int inventorySelectMenu() {
  int usrChoice;

  std::cout << "\nPlease select from the following options:\n"
            << "   1. Check Inventory\n"
            << "   2. Move items to chest\n"
            << "   3. Take items from chest\n"
            << "   4. Discard items from chest\n"
            << "   5. Exit [go back Home] ";
  usrChoice = getInt (1,5);
  return usrChoice;
}

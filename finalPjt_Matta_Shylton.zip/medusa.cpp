/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  IMPLEMENTATION for the Medusa class.
*******************************************************************************/
#include "medusa.hpp"

/*******************************************************************************
Constructor for the Medusa class. Lets user choose the name.
inputs: nothing
return: nothing
*******************************************************************************/
Medusa::Medusa(std::string userName) {
  //2d6 Attack
  attackDie.push_back(Dice(6));
  attackDie.push_back(Dice(6));
  //2d6 Defense
  defenseDie.push_back(Dice(6));
  defenseDie.push_back(Dice(6));
  armor = 3;
  strength = 40;
  lives = 1;
  name = "Medusa";
  characterClass = "Medusa";
}

/*******************************************************************************
Destructor for the Medusa class
inputs: nothing
return: nothing
*******************************************************************************/
Medusa::~Medusa() {

}

/*******************************************************************************
Medusa attack function. Performs a dice roll for each defense die in the mem-
    ber vector.
inputs: calculated damage from the attack
return: int: the total damage taken
*******************************************************************************/
int Medusa::attack() {
  int diceRoll;
  diceRoll = Character::attack();

  if (12 == diceRoll) {
    /* Glare */
    std::cout << " ### MURDEROUS GLARE ### :-O\n";
    diceRoll = 999;
  } else if (diceRoll > 9) {
    /* Strong Attack Message */
    std::cout << "Medusa executed a Crushing Blow!\n"
              << "ATTACK points: " << diceRoll << '\n';
  } else {
    std::cout << "ATTACK points: " << diceRoll << '\n';
  }
  return diceRoll;
}

/*******************************************************************************
Medusa defend function. Performs a dice roll for each defense die in the
  member vector. prints a message to the screen, calculates the damage taken,
  update the strength attribute.
inputs: caclulated damage from the attack
return: int: the total damage taken
*******************************************************************************/
int Medusa::defend(int damagePts) {
  int damageTaken, diceRoll;
  diceRoll = Character::defend(damagePts);
  damageTaken = std::max( 0, (damagePts - diceRoll - armor) );//cant be negative


  if (0 == damageTaken) {
    /* Parry defense message */
    std::cout << "DEFENSE points: " << diceRoll << '\n'
              << " ### Attack Parried! ###" << '\n'
              << "Inflicted damage: " << damageTaken << std::endl;
  } else {
    std::cout << "DEFENSE points: " << diceRoll << '\n'
              << "Inflicted damage: " << damageTaken << std::endl;
  }

  strength -= damageTaken; //update strength attribute

  //decrements the number of lives if strength reaches zero
  if (strength < 1) {
    std::cout << "Medusa updated strength: " << strength << '\n';
    std::cout << "Medusa is dead !!!" << '\n';
    std::cout << "\n   ### CONGRATULATIONS ###\n\n"
              << "  Medusa is defeated and Faye returns home safely\n"
              << "           with her beloved Kratos !\n";
    std::cout << "\nPress [Enter] to continue ";
    std::cin.get();
    --lives;
  } else {
    std::cout << "Medusa updated strength: " << strength << '\n';
  }
  return damageTaken;
}

/*******************************************************************************
Resets attributes post fight, to get ready for next one.
inputs: nothing
return: void
*******************************************************************************/
void Medusa::postFightReset() {
  armor = 3;
  strength = 30;
  lives = 1;
}

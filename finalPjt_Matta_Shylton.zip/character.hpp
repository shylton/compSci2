/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  SPECIFICATION for the character base class. This is an Abstract
    class. The attack and defend functions MUST be implemented in child classes.
    As well as the default constructor. Member variables:
      - a vector to hold attack dice and one to hold defense dice
      - int for the character attributes of armor, strength and number of lives
    detailed function Descriptions in the implementation file.
*******************************************************************************/

#ifndef CHARACTER_HPP
#define CHARACTER_HPP

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>//for max()
#include <cstdlib>  // For srand() and rand()
#include "dice.hpp"
#include "storage.hpp"

class Character {
protected:
  std::vector<Dice> attackDie;
  std::vector<Dice> defenseDie;
  int armor,
      strength,
      lives,
      level,
      moves;
  std::string name,
              characterClass;
  bool theEnd;

public:
  Character();
  virtual ~Character();
  Storage* backpack;
  std::string getClass();
  int getStrength();
  int getArmor();
  std::string getName();
  bool isDead();
  void levelUp();
  int getLevel();
  void setMoves(int input = -1);
  int getMoves();
  bool endGame();
  void showStats();
  void preFightSetup();
  virtual int attack() = 0;
  virtual int defend(int damagePts) = 0;
  virtual void postFightReset() = 0;
};

#endif /* end of include guard: CHARACTER_HPP */

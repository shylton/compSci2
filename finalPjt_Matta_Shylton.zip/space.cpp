/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  Header file for the Space class
*******************************************************************************/

#include "space.hpp"

/*******************************************************************************
* Constructor for the base class
*******************************************************************************/
Space::Space() {
  above = toRight = below = toLeft = nullptr;
  hero = nullptr;
  locked = true;
  active = false;
  unlockLvl = 3;
  name = "Not Set";
}

/*******************************************************************************
* Destructor for the base class
*******************************************************************************/
Space::~Space () {}

/*******************************************************************************
* sets pointers, will be used once to link all spaces
inputs: up, right, down, left, pointers in order
return: void
*******************************************************************************/
void Space::setPtrs(Character *p1, Space *u, Space *r, Space *d, Space *l) {
  hero = p1;
  above = u;
  toRight = r;
  below = d;
  toLeft = l;
}

/*******************************************************************************
inputs: nothing
return: string: name
*******************************************************************************/
std::string Space::getName() {
  return name;
}

/*******************************************************************************
inputs: nothing
return: string: "invalid" if nullptr, name otherwise
*******************************************************************************/
std::string Space::adjacentName(direction dir) {
  std::string rtn;

  switch (dir) {
    case na: {
      break;
    }
    case up: {
      if (!above) {
        rtn = "Out of Bounds";
      } else {
        rtn = above->getName();
      }
      break;
    }
    case right: {
      if (!toRight) {
        rtn = "Out of Bounds";
      } else {
        rtn = toRight->getName();
      }
      break;
    }
    case down: {
      if (!below) {
        rtn = "Out of Bounds";
      } else {
        rtn = below->getName();
      }
      break;
    }
    case left: {
      if (!toLeft) {
        rtn = "Out of Bounds";
      } else {
        rtn = toLeft->getName();
      }
      break;
    }
  }

  return rtn;
}

/*******************************************************************************
inputs: nothing
return: int: the preset unlock level
*******************************************************************************/
int Space::getUnlockLvl() {
  return unlockLvl;
}

/*******************************************************************************
unlocks if enough level has been reached are held in inventory, then returns locked status
inputs: nothing
return: bool: true if locked
*******************************************************************************/
bool Space::unlock() {
  bool rtn = false;
  if ( hero->getLevel() >= Space::getUnlockLvl() ) {
    rtn = true;
  }
  return rtn;
}

/*******************************************************************************
updates the curernt space to the one pointed to by direction
inputs: direction, space pointer: the same one that called the function
return: space pointer: either same one that called or new one if unlocked
*******************************************************************************/
Space * Space::move(direction input, Space *currSpace) {
  Space *rtn = currSpace;

  switch (input) {
    //this case should not happen
    case na:{
      std::cout << "oopsie, @ Space.move()" << '\n';
      break;
    }
    //UP
    case up:{
      if (!above) {
        /* above is null */
        std::cout << "Not a valid direction." << '\n';
      } else if (above->unlock()) {//unlock returns true if can unlock
        std::cout << "Moving to " << above->getName() << '\n';
        rtn = above;
      } else {
        std::cout << "Can't move there yet. Defeat enemies to level up." << '\n';
      }
      break;
    }
    //RIGHT
    case right:{
      if (!toRight) {
        /* toRight is null */
        std::cout << "Not a valid direction." << '\n';
      } else if (toRight->unlock()) {//unlock returns true if can unlock
        std::cout << "Moving to " << toRight->getName() << '\n';
        rtn = toRight;
      } else {
        std::cout << "Can't move there yet. Defeat enemies to level up." << '\n';
      }
      break;
    }
    //BELOW
    case down:{
      if (!below) {
        /* below is null */
        std::cout << "Not a valid direction." << '\n';
      } else if (below->unlock()) {//unlock returns true if can unlock
        std::cout << "Moving to " << below->getName() << '\n';
        rtn = below;
      } else {
        std::cout << "Can't move there yet. Defeat enemies to level up." << '\n';
      }
      break;
    }
    //LEFT
    case left:{
      if (!toLeft) {
        /* toLeft is null */
        std::cout << "Not a valid direction." << '\n';
      } else if (toLeft->unlock()) {//unlock returns true if can unlock
        std::cout << "Moving to " << toLeft->getName() << '\n';
        rtn = toLeft;
      } else {
        std::cout << "Can't move there yet. Defeat enemies to level up." << '\n';
      }
      break;
    }
  }
  return rtn;
}

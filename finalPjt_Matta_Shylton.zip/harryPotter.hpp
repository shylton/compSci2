/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  SPECIFICATION for the HarryPotter class. Member variables:
      - a vector to hold attack dice and one to hold defense dice
      - int for the character attributes of armor, strength and number of lives
    detailed function Descriptions in the implementation file.
*******************************************************************************/
#ifndef HARRYPOTTER_HPP
#define HARRYPOTTER_HPP

#include "character.hpp"

class HarryPotter : public Character {
public:
  HarryPotter(std::string userName = "Harry Potter");
  ~HarryPotter();
  int attack();
  int defend(int damagePts);
  //void preFightSetup();
  void postFightReset();
};

#endif /* end of include guard: HARRYPOTTER_HPP */

/*******************************************************************************
* Author:       Shylton Matta
* Date:         27 Jul 2019
* Description:  IMPLEMENTATION for three recursive functions.
    1. reverseString Reverses the string passed to it.
    2. sumArray sums an array of ints passed to it.
    3. triangularNumber receives N and returns the Nth triangular number.
*******************************************************************************/

#include "game.hpp"

/*******************************************************************************
Default constructor
inputs: nothing
return: nothing
*******************************************************************************/
Game::Game() {
  attacker = defender = nullptr;
  currentRound = 1;
}

/*******************************************************************************
Constructor, sets the characters
inputs: nothing
return: nothing
*******************************************************************************/
Game::Game(Character *p1, Character *p2) {
  bool p1Attacker = (rand() % 100 > 49);
  currentRound = 1;

  if (p1Attacker) {
    attacker = p1;
    defender = p2;
  } else {
    attacker = p2;
    defender = p1;
  }

}

/*******************************************************************************
Play a game with preset players
inputs: nothing
return: nothing
*******************************************************************************/
int Game::start1() {
  int attackPts;
  bool anotherRound = true;

  if (attacker == nullptr || defender == nullptr) {
    std::cout << "ERROR: Game not ready. ending" << '\n';
    return -1;
  }

//Run Game
  do {
    std::cout << std::string(28,' ') << "ROUND: " << currentRound << '\n'
              << std::string(64,'-') << '\n';//centered Round title

    std::cout << attacker->getClass() << " is attacking.\n"
              << "Defender type | armor | strength points\n";
    std::cout.width(14); std::cout << std::left << defender->getClass() << "|   ";
    std::cout.width(4); std::cout << defender->getArmor() << '|';
    std::cout << "   " << defender->getStrength() << std::endl;

    attackPts = attacker->attack();
    defender->defend(attackPts);

    if (defender->isDead()) {//game over
      anotherRound = false;
      std::cout << '\n' << attacker->getName() << " WINS!" << '\n';
      attacker->postFightReset();
      defender->postFightReset();
      endFight();//levels up player if wins
    }

    currentRound++;
    swapAttacker();//current defender becomes attacker
    std::cout << std::string(64,'-') << '\n';
  } while( anotherRound );

  return 0;
}

/*******************************************************************************
display message and level up
inputs: nothing
return: void
*******************************************************************************/
void Game::endFight() {
  if ("Kratos" == attacker->getName()) {
    /* Kratos wins, level up */
    std::cout << " ### The hero Kratos defeated the evil "
              << defender->getName() << " ! ###\n";
    attacker->levelUp();
  } else {
    /* Kratos lost, message */
    std::cout << "Kratos lost the battle against "
              << attacker->getName() << ".\n"
              << "[Tip: level up to get stronger attacks, or collect items]\n";
  }
}
/*******************************************************************************
Destructor for the class
inputs: nothing
return: nothing
*******************************************************************************/
Game::~Game() {

}
/*******************************************************************************
sets current defender to attacker and vice versa
inputs: nothing
return: nothing
*******************************************************************************/
void Game::swapAttacker() {
  Character *temp;
  temp = attacker;
  attacker = defender;
  defender = temp;

}

/*******************************************************************************
* Author:       Shylton Matta
* Date:         30 Jul 2019
* Description:  SPECIFICATION for the BlueMen class. Member variables:
      - a vector to hold attack dice and one to hold defense dice
      - int for the character attributes of armor, strength and number of lives
    detailed function Descriptions in the implementation file.
*******************************************************************************/
#ifndef BLUEMEN_HPP
#define BLUEMEN_HPP

#include "character.hpp"

class BlueMen : public Character {
public:
  BlueMen(std::string userName = "Na'vi");
  ~BlueMen();
  int attack();
  int defend(int damagePts);
  void resetDiceCount();
  void postFightReset();
  //void preFightSetup() {};
};

#endif /* end of include guard: BLUEMEN_HPP */

/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  IMPLEMENTATION for the Storage class. It has 6 slots which can
    contain items listed in the enum declaration. also functions to add, remove
    and show.
*******************************************************************************/

#include "storage.hpp"

/*******************************************************************************
Constructor sets all slots to empty
inputs: nothing
return: nothing
*******************************************************************************/
Storage::Storage(int sz){
  size = sz;
  for (int i = 0; i < size; ++i) {
    myItems.push_back(empty);
  }
}

/*******************************************************************************
function to display the contents of the backpack
inputs: nothing
return: void
*******************************************************************************/
void Storage::showItems() {
  myItems.sort();
  int i = 1;
  std::string printMe;

  for (auto iter = myItems.begin(); iter != myItems.end(); ++iter) {
    std::cout << "Slot_" << i << ": " << lookup.find(*iter)->second << '\n';
    ++i;
  }
}

/*******************************************************************************
function to add a specified item to the backpack
inputs: int: number of items to add, items: the type of item
return: void
*******************************************************************************/
void Storage::addItem(int qty, items addMe) {
  myItems.sort();//sorting so empty slots are at the front
  auto iter = myItems.begin();

  for (int i = 0; i < qty; i++) {
    if (0 == itemCount(empty)) {
      std::cout << "Backpack full." << '\n';
      i = qty;//to exit the for loop
    } else if (empty == *iter) {
      iter = myItems.erase(iter);
      myItems.push_back(addMe);
    }
  }
  myItems.sort();
}

/*******************************************************************************
function to remove a specified item to the backpack
inputs: int: number of items to add, items: the type of item
return: void
*******************************************************************************/
void Storage::removeItem( int qty, items delMe) {
  myItems.sort();
  bool looper = true;
  auto iter = myItems.begin();
  while (iter != myItems.end() && qty > 0) {

    if (delMe == *iter) {
      iter = myItems.erase(iter);//[note] erase auto increments iter. super cool
      myItems.push_back(empty);
      qty--;
    } else {
      iter++;
    }
  }
  myItems.sort();
}

/*******************************************************************************
inputs: items: the type of item to count
return: int: the amount of the requested item in the class
*******************************************************************************/
int Storage::itemCount(items request) {
  int count = 0;

  for (auto iter = myItems.begin(); iter != myItems.end(); ++iter) {
    if (request == *iter) {
      count++;
    }
  }
  return count;
}

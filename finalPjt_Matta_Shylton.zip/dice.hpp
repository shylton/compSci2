/*******************************************************************************
* Author:       Shylton Matta
* Date:         27 Jul 2019
* Description:  SPECIFICATION for the dice class
*******************************************************************************/

#ifndef DICE_HPP
#define DICE_HPP

#include <iostream>
#include <string>
#include <cstdlib>  // For srand() and rand()

class Dice {
private:
  int sides;

public:
  Dice(int s);
  int roll();
  void setSides(int s);

};

#endif /* end of include guard: DICE_HPP */

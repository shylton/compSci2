/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  Header file for the inventory Space class, this the left space
    where you can deal with inventory.
    - to the right there is a base space
    - all other directions are null
*******************************************************************************/
#ifndef INVENTORY_SPACE_HPP
#define INVENTORY_SPACE_HPP

#include <algorithm>
#include "helpers.hpp"
#include "space.hpp"
#include "storage.hpp"

class InventorySpace : public Space {
private:
  Storage *chest;

public:
  InventorySpace (std::string nm, int boss);
  ~InventorySpace ();
  Space* action(Space *currSpace);
  void moveItemsMenu(int &iType, int &iQty, std::string s);
};

#endif /* end of include guard: INVENTORY_SPACE_HPP */

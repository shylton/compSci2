/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  Header file for the Base Space class, this the central space
    where you can fight a boss or rest.
    - to the left there is an inventory space
    - to the right there is a cardGame space
*******************************************************************************/
#ifndef BASE_SPACE_HPP
#define BASE_SPACE_HPP

#include "helpers.hpp"
#include "space.hpp"
#include "game.hpp"


class BaseSpace : public Space {
private:
  Game *fight1;
  Character *opponent;

public:
  BaseSpace (std::string nm, int boss);
  ~BaseSpace ();
  Space* action(Space *currSpace);
  //BaseSpace menus
  void baseGreeting();
  int baseSelectMenu();
  Space* baseMoveMenu(Space* currSpace);

};


#endif /* end of include guard: BASE_SPACE_HPP */

/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  Header file for the Space class
*******************************************************************************/
#ifndef SPACE_HPP
#define SPACE_HPP

#include "helpers.hpp"
#include "character.hpp"

enum direction { na, up, right, down, left };

class Space {
protected:
  Space *above,
        *toRight,
        *below,
        *toLeft;
  bool locked,
       active;
  int unlockLvl;
  Character *hero;
  std::string name;

public:
  Space ();
  virtual ~Space ();
  void setPtrs(Character *p1, Space *u, Space *r, Space *d, Space *l);
  bool unlock();
  int getUnlockLvl();
  Space* move(direction input, Space *currSpace);
  std::string getName();
  std::string adjacentName(direction dir);
  virtual Space* action(Space *currSpace) = 0;
};

#endif /* end of include guard: SPACE_HPP */

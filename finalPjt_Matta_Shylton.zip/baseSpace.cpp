/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  IMPLEMENTATION the Base Space class, this the central space
    where you can fight a boss or rest.
    - to the left there is an inventory space
    - to the right there is a cardGame space
*******************************************************************************/
#include "baseSpace.hpp"

/*******************************************************************************
constructor
inputs: string: name, int boss to setup opponent
return: void
*******************************************************************************/
BaseSpace::BaseSpace(std::string nm, int boss) : Space () {
  fight1 = nullptr;
  name = nm;
  unlockLvl = boss;

  switch (boss) {
    case 0: {
      opponent = nullptr;
      break;
    }
    case 1: {
      opponent = new Barbarian();
      break;
    }
    case 2: {
      opponent = new Vampire();
      break;
    }
    case 3: {
      opponent = new BlueMen();
      break;
    }
    case 4: {
      opponent = new Medusa();
      break;
    }
    default: {
      std::cout << "oopsie, @ BaseSpace constructor" << '\n';
      break;
    }
  }
}

/*******************************************************************************
destructor
inputs: nothing
return: nothing
*******************************************************************************/
BaseSpace::~BaseSpace() {
  delete opponent;
  opponent = nullptr;
  // delete fight1;
  // fight1 = nullptr;
}

/*******************************************************************************
performs an action based on the type of Space. in this case a fight ensues.
inputs: character: the player
return: int: tbd
*******************************************************************************/
Space* BaseSpace::action(Space *currSpace) {

  int selection;
  Space *nextSpace = currSpace;

  // STEP 1. Greeting
  clearScrn();
  baseGreeting();
  std::cout << "  Current Stats:\n";
  hero->showStats();
  std::cout << "  Backpack:" << '\n';
  hero->backpack->showItems();

  //STEP2. Fight or move
  selection = baseSelectMenu();
  switch (selection) {
    case 1: {
      if (!opponent) {
        /* opponent = null, prob @ space without opponent */
        std::cout << "Can't fight here." << '\n';
      } else {
        hero->setMoves();//steps decremented each time a fight is called
        hero->preFightSetup();
        fight1 = new Game(hero, opponent);
        fight1->start1();
        delete fight1;
        fight1 = nullptr;
      }
      break;
    }
    case 2: {
      nextSpace = baseMoveMenu(currSpace);
      break;
    }
    case 3: {
      hero->setMoves(-999);
      break;
    }
    default: {
      std::cout << "oopsie, @ BaseSpace->action" << '\n';
      break;
    }
  }
  pressKey();

  return nextSpace;
}

/*******************************************************************************
Shows intro message for inventory space
inputs: nothing
return: void
*******************************************************************************/
void BaseSpace::baseGreeting() {
  std::cout << std::string(64,'=') << std::endl
            << '|' << std::string(20, ' ')
            << "Welcome to " << Space::getName()
            << std::string(18, ' ') << "|\n"
            << '|' << std::string(24, ' ')
            << "Fight or Flight!"
            << std::string(22, ' ') << "|\n"
            << std::string(64,'=') << std::endl;
}

/*******************************************************************************
Shows a menu for user selection
inputs: nothing
return: int: user choice
*******************************************************************************/
int BaseSpace::baseSelectMenu() {
  int usrChoice;

  std::cout << "\nPlease select from the following options:\n"
            << "   1. Fight the Boss\n"
            << "   2. Move to another space\n"
            << "   3. Quit Game ";
  usrChoice = getInt (1,3);
  return usrChoice;
}

/*******************************************************************************
Shows a menu for user selection
inputs: nothing
return: int: user choice
*******************************************************************************/
Space* BaseSpace::baseMoveMenu(Space* currSpace) {
  Space* rtn = currSpace;
  bool looper = true;
  int usrChoice;

  std::string up1 = adjacentName(up);//gets name for non-nullptr
  std::string down1 = adjacentName(down);
  std::string left1 = adjacentName(left);
  std::string right1 = adjacentName(right);

  std::cout << "\nPlease select from the following options:\n"
            << "   1. Move up to: " << up1 << '\n'
            << "   2. Move down to: " << down1 << '\n'
            << "   3. Move left to: " << left1 << '\n'
            << "   4. Move right to: " << right1 << '\n'
            << "   5. Cancel [stay here] ";

  do {
    usrChoice = getInt (1,5);
    switch (usrChoice) {
      case 1: {
        if ("Out of Bounds" == up1) {
          std::cout << "Can't move there. Please try again ";
        } else {
          rtn = Space::move(up, currSpace);
          looper = false;
        }
        break;
      }
      case 2: {
        if ("Out of Bounds" == down1) {
          std::cout << "Can't move there. Please try again ";
        } else {
          rtn = Space::move(down, currSpace);
          looper = false;
        }
        break;
      }
      case 3: {
        if ("Out of Bounds" == left1) {
          std::cout << "Can't move there. Please try again ";
        } else {
          rtn = Space::move(left, currSpace);
          looper = false;
        }
        break;
      }
      case 4: {
        if ("Out of Bounds" == right1) {
          std::cout << "Can't move there. Please try again ";
        } else {
          rtn = Space::move(right, currSpace);
          looper = false;
        }
        break;
      }
      case 5: {
        looper = false;
        break;
      }
    }//end of switch
  } while(looper);

  return rtn;
}

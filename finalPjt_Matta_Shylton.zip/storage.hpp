/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  SPECIFICATION for the Storage class. It has 6 slots which can
    contain items listed in the enum declaration. also functions to add, remove
    and show.
*******************************************************************************/

#ifndef STORAGE_HPP
#define STORAGE_HPP

#include <iostream>
#include <list>
#include <map>
#include <string>

enum items { empty, lifeGem, garlic, shield };

class Storage {
private:
  int size;
  std::list<items> myItems;
  const std::map<items, std::string> lookup = {
                { empty, "Empty" },
                { lifeGem, "Life-Gem" },
                { garlic, "Holy-Garlic" },
                { shield, "Plank-Shield" } };

public:
  Storage (int sz = 4);
  void addItem(int qty, items addMe);
  void removeItem(int qty, items delMe);
  void showItems();
  int itemCount(items request);
};


#endif /* end of include guard: STORAGE_HPP */

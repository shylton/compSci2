/*******************************************************************************
* Author:       Shylton Matta
* Date:         12 Aug 2019
* Description:  just the main file. sets up the spaces and pointers then runs
      a simulation. [note] to change number of "moves" allowed goto
      harryPotter.cpp file.
*******************************************************************************/

#include <ctime>
#include <cstdlib>  // For srand() and rand()
#include "helpers.hpp"
#include "baseSpace.hpp"
#include "inventorySpace.hpp"
#include "trucoSpace.hpp"
#include "harryPotter.hpp"

int main() {
  srand(time(0));
  int choice;

//STEP0. Main Menu, options to start, quit or show info message
  do {
    choice = mainMenu();
    if (2 == choice) {
      showHistory();
    } else if (3 == choice) {
      showMap();
    }
  } while(2 == choice || 3 == choice);

//STEP 1. Setup the hero and all linked spaces
  if (1 == choice) {
    Character *theHero;
    theHero = new HarryPotter("Kratos");

    Space *activeSpace;
    Space *homeBase;
    homeBase = new BaseSpace("Home Base    ",0);//name must have 13 chars to print centered
    Space *inventory;
    inventory = new InventorySpace("Inventory",0);
    Space *kronosHouse;
    kronosHouse = new TrucoSpace("Krono's House",0);

    Space *base1;
    base1 = new BaseSpace("Conan's Field",1);
    Space *base2;
    base2 = new BaseSpace("Dracula Manor",2);
    Space *base3;
    base3 = new BaseSpace("Blue Men Cave",3);
    Space *base4;
    base4 = new BaseSpace("Medusa's Lair",4);

    //link all spaces (hero, above, toright, below, toleft)
    homeBase->setPtrs(theHero, base1, kronosHouse, nullptr, inventory);
    inventory->setPtrs(theHero, nullptr, homeBase, nullptr, nullptr);
    kronosHouse->setPtrs(theHero, nullptr, nullptr, nullptr, homeBase);
    base1->setPtrs(theHero, base2, kronosHouse, homeBase, inventory);
    base2->setPtrs(theHero, base3, kronosHouse, base1, inventory);
    base3->setPtrs(theHero, base4, kronosHouse, base2, inventory);
    base4->setPtrs(theHero, nullptr, kronosHouse, base3, inventory);

    // add items to test inventory
    //theHero->backpack->addItem(3, shield);

  //STEP 2. Start Game
  activeSpace = homeBase;
  do {
    activeSpace = activeSpace->action(activeSpace);
  } while( !theHero->endGame() );

  //WRAP UP
    delete theHero;
    delete homeBase;
    delete inventory;
    delete kronosHouse;
    delete base1;
    delete base2;
    delete base3;
    delete base4;

  }//end of main if. go here if user chose quit

  std::cout << "Thanks for Playing" << '\n';
  return 0;
}
